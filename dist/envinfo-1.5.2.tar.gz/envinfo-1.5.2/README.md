# envinfo

[![GuardRails badge](https://badges.production.guardrails.io/mrstephenneal/envinfo.svg)](https://www.guardrails.io)

A lightweight Python utility for retrieving system information and specifications.
