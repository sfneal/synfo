# envinfo
A lightweight Python utility for retrieving system information and specifications.
